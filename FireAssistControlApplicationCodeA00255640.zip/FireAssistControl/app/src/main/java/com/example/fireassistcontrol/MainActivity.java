package com.example.fireassistcontrol;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        //listeners for buttons on the main screen
        ImageButton physicalButton = findViewById(R.id.physButton);
        physicalButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, PhysActivity.class);
            startActivity(intent);

        });
        ImageButton voiceButton = findViewById(R.id.voiceButton);
        voiceButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, VoiceActivity.class);
            startActivity(intent);

        });
        ImageButton gyroButton = findViewById(R.id.gyroButton);
        gyroButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, GyroActivity.class);
            startActivity(intent);

        });

    }
    @Override
    public void onPause() {
        super.onPause();
    }
    public void onResume() {
        super.onResume();
    }
    public void onStop() {
        super.onStop();
    }


}