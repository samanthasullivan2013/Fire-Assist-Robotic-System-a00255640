package com.example.bluetoothbasicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.speech.RecognizerIntent;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class VoiceActivity extends AppCompatActivity {
    private final int REQ_CODE = 100;
    private TextView textView;
    BluetoothConnectService mBtService;
    boolean mBound = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_voice);
        textView = findViewById(R.id.text);
        ImageButton speak = findViewById(R.id.mic);
        speak.setOnClickListener(v -> {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Enter a command");
            try {
                startActivityForResult(intent, REQ_CODE);
            } catch (ActivityNotFoundException a) {
                Toast.makeText(getApplicationContext(),
                        "Sorry your device not supported",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQ_CODE: {
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                    textView.setText((CharSequence) result.get(0));
                    String voiceInput = (String) textView.getText();
                    switch (voiceInput) {
                        case "forward":
                            // Command to drive forward on Arduino. Must match with the command in Arduino code
                            mBtService.goForward();
                            break;
                        case "backwards":
                            // Command to drive backwards on Arduino. Must match with the command in Arduino code
                            mBtService.goBackwards();
                            break;
                        case "left":
                            // Command to turn left on Arduino. Must match with the command in Arduino code
                            mBtService.goLeft();
                            break;
                        case "right":
                            // Command to turn right on Arduino. Must match with the command in Arduino code
                            mBtService.goRight();
                            break;
                        case "stop":
                            // Command to stop on Arduino. Must match with the command in Arduino code
                            mBtService.stopMotors();
                            break;
                        case "lights on":
                            // Command to turn on LED on Arduino. Must match with the command in Arduino code
                            mBtService.lightsOn();
                            break;
                        case "lights off":
                            // Command to turn on LED off Arduino. Must match with the command in Arduino code
                            mBtService.lightsOff();
                            break;
                        case "auto":
                            // Command to enter automode on Arduino. Must match with the command in Arduino code
                            mBtService.autoMode();
                            break;
                    }
                }
                break;
            }
        }
    }
    @Override
    protected void onStart() {
        super.onStart();
        // Bind to LocalService
        Intent intent = new Intent(this, BluetoothConnectService.class);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unbindService(connection);
        mBound = false;
    }
    /** Defines callbacks for service binding, passed to bindService() */
    private ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName className,
                                       IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            BluetoothConnectService.LocalBinder binder = (BluetoothConnectService.LocalBinder) service;
            mBtService = binder.getService();
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
        }
    };
}