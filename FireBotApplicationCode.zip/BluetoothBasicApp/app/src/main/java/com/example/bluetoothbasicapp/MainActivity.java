package com.example.bluetoothbasicapp;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final int PERMISSION_CODE = 123;

    BluetoothConnectService mBtService;
    boolean mBound = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_main);


        //listeners for buttons on the main screen
        ImageButton physicalButton = findViewById(R.id.physButton);
        physicalButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, PhysActivity.class);
            startActivity(intent);

        });
        ImageButton voiceButton = findViewById(R.id.voiceButton);
        voiceButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, VoiceActivity.class);
            startActivity(intent);

        });
        ImageButton gyroButton = findViewById(R.id.gyroButton);
        gyroButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, GyroActivity.class);
            startActivity(intent);

        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Bind to LocalService
        Intent intent = new Intent(this, BluetoothConnectService.class);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        //interferes with changing between controllers
        //unbindService(connection);
      //  mBound = false;
    }

    /** Defines callbacks for service binding, passed to bindService() */
    private ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            BluetoothConnectService.LocalBinder binder = (BluetoothConnectService.LocalBinder) service;
            mBtService = binder.getService();
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
        }
    };

}