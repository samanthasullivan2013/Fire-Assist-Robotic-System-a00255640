package com.example.bluetoothbasicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.ImageButton;

public class PhysActivity extends AppCompatActivity {
    private int lightflag = 0;
    BluetoothConnectService mBtService;
    boolean mBound = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_phys);

        final ImageButton upButtonToggle = findViewById(R.id.upButton);
        final ImageButton downButtonToggle = findViewById(R.id.downButton);
        final ImageButton leftButtonToggle = findViewById(R.id.leftButton);
        final ImageButton rightButtonToggle = findViewById(R.id.rightButton);
        final ImageButton stopButtonToggle = findViewById(R.id.stopButton);
        final ImageButton exButtonToggle = findViewById(R.id.extinguishButton);
        final ImageButton lightsButtonToggle = findViewById(R.id.lightButton);

//         Buttons to control Arduino Robot
        upButtonToggle.setOnClickListener(view -> {
            if (mBound) {
                mBtService.goForward();
                upButtonToggle.setImageResource(R.drawable.uparrowon);
                downButtonToggle.setImageResource(R.drawable.downarrow);
                leftButtonToggle.setImageResource(R.drawable.leftarrow);
                rightButtonToggle.setImageResource(R.drawable.rightarrow);
                stopButtonToggle.setImageResource(R.drawable.stop);
                exButtonToggle.setImageResource(R.drawable.extinguisher);
            }
        });
        downButtonToggle.setOnClickListener(view -> {
            if (mBound) {
                mBtService.goBackwards();

                upButtonToggle.setImageResource(R.drawable.uparrow);
                downButtonToggle.setImageResource(R.drawable.downarrowon);
                leftButtonToggle.setImageResource(R.drawable.leftarrow);
                rightButtonToggle.setImageResource(R.drawable.rightarrow);
                stopButtonToggle.setImageResource(R.drawable.stop);
                exButtonToggle.setImageResource(R.drawable.extinguisher);
            }
        });
        leftButtonToggle.setOnClickListener(view -> {
            if (mBound) {
                mBtService.goLeft();
                upButtonToggle.setImageResource(R.drawable.uparrow);
                downButtonToggle.setImageResource(R.drawable.downarrow);
                leftButtonToggle.setImageResource(R.drawable.leftarrowon);
                rightButtonToggle.setImageResource(R.drawable.rightarrow);
                stopButtonToggle.setImageResource(R.drawable.stop);
                exButtonToggle.setImageResource(R.drawable.extinguisher);
            }
        });
        rightButtonToggle.setOnClickListener(view -> {
            if (mBound) {
                mBtService.goRight();
                upButtonToggle.setImageResource(R.drawable.uparrow);
                downButtonToggle.setImageResource(R.drawable.downarrow);
                leftButtonToggle.setImageResource(R.drawable.leftarrow);
                rightButtonToggle.setImageResource(R.drawable.rightarrowon);
                stopButtonToggle.setImageResource(R.drawable.stop);
                exButtonToggle.setImageResource(R.drawable.extinguisher);
            }
        });
        stopButtonToggle.setOnClickListener(view -> {
            if (mBound) {
                mBtService.stopMotors();
                upButtonToggle.setImageResource(R.drawable.uparrow);
                downButtonToggle.setImageResource(R.drawable.downarrow);
                leftButtonToggle.setImageResource(R.drawable.leftarrow);
                rightButtonToggle.setImageResource(R.drawable.rightarrow);
                stopButtonToggle.setImageResource(R.drawable.stopon);
                exButtonToggle.setImageResource(R.drawable.extinguisher);
            }
        });
        exButtonToggle.setOnClickListener(view -> {
            if (mBound) {
                mBtService.autoMode();
                upButtonToggle.setImageResource(R.drawable.uparrow);
                downButtonToggle.setImageResource(R.drawable.downarrow);
                leftButtonToggle.setImageResource(R.drawable.leftarrow);
                rightButtonToggle.setImageResource(R.drawable.rightarrow);
                stopButtonToggle.setImageResource(R.drawable.stop);
                exButtonToggle.setImageResource(R.drawable.extinguisheron);
            }
        });
        lightsButtonToggle.setOnClickListener(view -> {
            if (mBound) {
                if(lightflag==0) {
                    mBtService.lightsOn();
                    lightsButtonToggle.setImageResource(R.drawable.lightbulbon);
                    lightflag =1;
                }
                else if(lightflag==1){
                    mBtService.lightsOff();
                    lightsButtonToggle.setImageResource(R.drawable.lightbulboff);
                    lightflag =0;
                }
            }

        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Bind to LocalService
        Intent intent = new Intent(this, BluetoothConnectService.class);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unbindService(connection);
        mBound = false;
    }

    /** Defines callbacks for service binding, passed to bindService() */
    private ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            BluetoothConnectService.LocalBinder binder = (BluetoothConnectService.LocalBinder) service;
            mBtService = binder.getService();
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
        }
    };
}