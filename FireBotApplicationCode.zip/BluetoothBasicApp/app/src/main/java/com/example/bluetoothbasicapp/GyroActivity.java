package com.example.bluetoothbasicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.TextView;

public class GyroActivity extends AppCompatActivity implements SensorEventListener {
    BluetoothConnectService mBtService;
    boolean mBound = false;
    private TextView textX;
    private SensorManager sensorManager;
    private Sensor AccSensor;
    int flag =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_gyro);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        AccSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        textX = findViewById(R.id.gyrotestx);
    }
    public void onResume() {
        super.onResume();
        //register listeners for sensor
        sensorManager.registerListener(this,AccSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }
    @Override
    protected void onStart() {
        super.onStart();
        // Bind to LocalService
        Intent intent = new Intent(this, BluetoothConnectService.class);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);
    }

    public void onStop() {
        super.onStop();
        //unregister listeners for sensor
        sensorManager.unregisterListener(this);
        unbindService(connection);
        mBound = false;
    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (mBound) {
            if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                //get the sensor values
                double x = event.values[0];

                //print values to textfield
                textX.setText("X : " + (String.format("%.2f", x)) + " m/s");

                if (x < 2.00 && x > 0.01 && flag == 0) {
                    mBtService.autoMode();
                    flag = 1;
                }
                else if (x > 9.00 && x < 10.00 && flag == 1) {
                    mBtService.stopMotors();
                    flag = 0;
                }

            }
        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    /** Defines callbacks for service binding, passed to bindService() */
    private ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName className,
                                       IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            BluetoothConnectService.LocalBinder binder = (BluetoothConnectService.LocalBinder) service;
            mBtService = binder.getService();
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
        }
    };
}